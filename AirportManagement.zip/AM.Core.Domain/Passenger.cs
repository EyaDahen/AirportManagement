﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AM.Core.Domain
{
    public class Passenger
    {
        //Properties 
        public DateTime BirthDate { get; set; }
        public string PassportNumber { get; set; }
        public string EmailAddress { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string TelNumber { get; set; }
        public int Age { get; set; }

        public IList<Flight> Flights { get; set; }

        //Methode qui permet de checker profile du passenger 
        public bool CheckProfile(string firstname , string lastname)
        {
            return this.FirstName == firstname && this.LastName == lastname;
        }

        public bool CheckProfile(string firstName, string lastName, string email)
        {
            return this.FirstName == firstName && this.LastName == lastName && this.EmailAddress == email;
        }

        //Methode qui permet de savoir l'identité du passenger 
        public virtual string GetPassengerType()
        {
            return "I am a passenger";
        }

        //Calculer age a partir de BirthDate
        public void GetAge(DateTime birthDate, ref int calculatedAge)
        {
            calculatedAge = DateTime.Now.Year - birthDate.Year;
        }
        public void GetAge(Passenger passenger)
        {
            passenger.Age = DateTime.Now.Year - passenger.BirthDate.Year;
        }

        public override string ToString()
        {
            return
                $"Passenger: {FirstName} {LastName}, " +
                $"Email: {EmailAddress}, " +
                $"Telphone Number: {TelNumber}, " +
                $"Passport Number: {PassportNumber}, " +
                $"Birth Date: {BirthDate.ToShortDateString()}";
        }
    }
}
